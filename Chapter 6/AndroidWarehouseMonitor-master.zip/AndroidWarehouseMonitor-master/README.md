# AndroidWarehouseMonitor
Code for Chapter 6 of the Book IOT Projects with Bluetooth Low Energy - https://www.packtpub.com/hardware-and-creative/iot-projects-bluetooth-low-energy
