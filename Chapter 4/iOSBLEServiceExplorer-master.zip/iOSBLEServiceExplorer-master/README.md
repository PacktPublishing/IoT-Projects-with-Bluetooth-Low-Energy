# iOSBLEServiceExplorer

Code for the iOSBLEServiceExplorer as described in the book IOT projects with Bluetooth Low Energy https://www.packtpub.com/books/info/authors/madhur-bhargava
