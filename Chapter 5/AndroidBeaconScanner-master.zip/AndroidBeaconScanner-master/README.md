# AndroidBeaconScanner
Android Eddystone Beacon Scanner Code as described in Chapter 5 of the Book: https://www.packtpub.com/hardware-and-creative/iot-projects-bluetooth-low-energy
